self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "118bb14dd486fb9e602b3af5faeaead2",
    "url": "/index.html"
  },
  {
    "revision": "e69db45cfa51db08f8be",
    "url": "/static/css/main.e20a41c7.chunk.css"
  },
  {
    "revision": "25c03fb858c906acdb23",
    "url": "/static/js/2.8655ddcc.chunk.js"
  },
  {
    "revision": "027776ab6aa4836b4c5a744c88932533",
    "url": "/static/js/2.8655ddcc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e69db45cfa51db08f8be",
    "url": "/static/js/main.37b58343.chunk.js"
  },
  {
    "revision": "ec08937535b419cc87cd",
    "url": "/static/js/runtime-main.118a965f.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);